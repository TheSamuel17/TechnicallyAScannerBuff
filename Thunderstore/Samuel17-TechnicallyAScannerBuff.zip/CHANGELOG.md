## 1.0.1

- Removed one (1) unnessecary hook. And then implemented a necessary one, but only if a new config is enabled.
- New config to keep item rarities identical to a small Chest.
- New config to make the Radar Scanner mandatory to find the bonus Cloaked Chests.
    - They're spawned upon scanning.
- Manifest & readme update (GitHub link was absent).

## 1.0.0

- Release.