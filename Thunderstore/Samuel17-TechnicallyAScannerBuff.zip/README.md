# TechnicallyAScannerBuff

Perhaps a reason to run Radar Scanner full-time now?

The unique Cloaked Chest does not lock itself during the Teleporter event, to make it even sneakier >:D

## Credits

* The denizens of `#development`, for answering my questions. Shoutouts Chinchi.

## Contact

I am `samuel17` on Discord. If you got feedback or bug reports, contact me either through DMs or the Risk of Rain 2 Modding Discord.