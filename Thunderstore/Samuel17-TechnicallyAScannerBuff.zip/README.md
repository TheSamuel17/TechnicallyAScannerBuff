# TechnicallyAScannerBuff

Perhaps a reason to run Radar Scanner full-time now?

The unique Cloaked Chest does not lock itself during the Teleporter event, to make it even sneakier >:D

### Config Options

* Chest count. (Default: 1)
* Chests have upgraded rarity. (Default: true)
* Chests will only show up if a Radar Scanner has actually been used. (Default: false)
    * <sup><sub>Keeping this "false" by default to uphold the primary goal of the mod, which was really just introducing a mechanic akin to Mario Party's Hidden Blocks. Hence the "technically" part.</sub></sup>

## Credits

* The denizens of `#development`, for answering my questions. Shoutouts Chinchi.

## Contact

I am `samuel17` on Discord. If you got feedback or bug reports, contact me either through DMs or the Risk of Rain 2 Modding Discord.